library('testthat')
library('acadcites')

test_check("acadcites")
